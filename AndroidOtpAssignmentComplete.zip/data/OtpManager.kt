package data

data class OtpData(
    val otp: String,
    val createdAt: Long,
    var attemptsLeft: Int
)

sealed class OtpResult {
    object Success : OtpResult()
    object Invalid : OtpResult()
    object Expired : OtpResult()
    object AttemptsExceeded : OtpResult()
}

class OtpManager {
    private val otpMap = mutableMapOf<String, OtpData>()
    private val expiryMillis = 60_000L

    fun generateOtp(email: String): String {
        val otp = (100000..999999).random().toString()
        otpMap[email] = OtpData(otp, System.currentTimeMillis(), 3)
        return otp
    }

    fun validateOtp(email: String, input: String): OtpResult {
        val data = otpMap[email] ?: return OtpResult.Invalid

        if (System.currentTimeMillis() - data.createdAt > expiryMillis) {
            return OtpResult.Expired
        }

        if (data.attemptsLeft <= 0) {
            return OtpResult.AttemptsExceeded
        }

        return if (data.otp == input) {
            OtpResult.Success
        } else {
            data.attemptsLeft--
            OtpResult.Invalid
        }
    }
}