package ui

import androidx.compose.runtime.*
import androidx.compose.material.*
import kotlinx.coroutines.delay

@Composable
fun SessionScreen(startTime: Long, onLogout: () -> Unit) {
    var seconds by remember { mutableStateOf(0L) }

    LaunchedEffect(Unit) {
        while (true) {
            seconds = (System.currentTimeMillis() - startTime) / 1000
            delay(1000)
        }
    }

    Text("Session duration: ${seconds / 60}:${seconds % 60}")
    Button(onClick = onLogout) {
        Text("Logout")
    }
}