package ui

import androidx.compose.runtime.*
import androidx.compose.material.*
import androidx.compose.ui.Modifier

@Composable
fun LoginScreen(onSendOtp: (String) -> Unit) {
    var email by rememberSaveable { mutableStateOf("") }

    Column {
        TextField(value = email, onValueChange = { email = it }, label = { Text("Email") })
        Button(onClick = { onSendOtp(email) }) {
            Text("Send OTP")
        }
    }
}