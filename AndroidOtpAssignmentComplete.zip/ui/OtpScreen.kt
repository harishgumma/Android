package ui

import androidx.compose.runtime.*
import androidx.compose.material.*

@Composable
fun OtpScreen(email: String, onVerify: (String) -> Unit) {
    var otp by rememberSaveable { mutableStateOf("") }

    Column {
        Text("OTP sent to $email")
        TextField(value = otp, onValueChange = { otp = it }, label = { Text("Enter OTP") })
        Button(onClick = { onVerify(otp) }) {
            Text("Verify")
        }
    }
}