package viewmodel

import androidx.compose.runtime.*
import androidx.lifecycle.ViewModel
import analytics.AnalyticsLogger
import data.OtpManager
import data.OtpResult

class AuthViewModel : ViewModel() {

    private val otpManager = OtpManager()

    var state by mutableStateOf<AuthState>(AuthState.Login)
        private set

    fun sendOtp(email: String) {
        otpManager.generateOtp(email)
        AnalyticsLogger.logOtpGenerated()
        state = AuthState.Otp(email)
    }

    fun verifyOtp(email: String, otp: String) {
        when (otpManager.validateOtp(email, otp)) {
            is OtpResult.Success -> {
                AnalyticsLogger.logOtpSuccess()
                state = AuthState.Session(System.currentTimeMillis())
            }
            is OtpResult.Invalid -> {
                AnalyticsLogger.logOtpFailure()
                state = AuthState.Error("Invalid OTP")
            }
            is OtpResult.Expired -> {
                state = AuthState.Error("OTP expired")
            }
            is OtpResult.AttemptsExceeded -> {
                state = AuthState.Error("OTP attempts exceeded")
            }
        }
    }

    fun logout() {
        AnalyticsLogger.logLogout()
        state = AuthState.Login
    }
}